import kaboom from "kaboom"
import "kaboom/global"

// initialize context
kaboom()

// define const
const PLAYERSPEED = 320
const BULLETSPEED = 1200
const ENEMYSPEED = 120
const CLOUDSPEED = 80

// define highscores
// for regular
let highreg = 5
// for insane mode
let highin = 5

// load assets
loadSprite("bullet", "sprites/bullet.png")
loadSprite("ghosty", "sprites/ghosty.png")
loadSprite("cloud", "sprites/cloud.png")
loadSprite("player", "sprites/player.png")
loadSound("hit", "sounds/hit.mp3")
loadSound("shoot", "sounds/shoot.mp3")
loadSound("mainMusic", "sounds/OtherworldlyFoe.mp3")
loadSound("error", "sounds/error.mp3")

// music loop
play("mainMusic", {
	loop: true,
})

function addinstruct () {
	const instruct = add([
		text("Press mouse to shoot ghosts!"),
		pos(width() / 2, height() / 2),
		anchor("center"),
		fixed(),
		color(0, 0, 0),
	])
	wait(5, () => {
		destroy(instruct)
		const moreinstruct = add([
			text("Use the left and right buttons to move horizontally."),
			pos(center()),
			anchor("center"),
			fixed(),
			color(0, 0, 0),
		])
		wait(5, () => {
			destroy(moreinstruct)
			const moreinstruct2 = add([
				text("Don't let the ghosts get past or touch you!"),
				pos(center()),
				anchor("center"),
				fixed(),
				color(0, 0, 0),
			])
			wait(7, () => {
				destroy(moreinstruct2)
			})
		})
	})
}









// regular mode
scene("regular", () => {
	// define simple variables
	let score = 0
	let bullets = 10

	// add bullet counter
	const numberbull = add([
		text("Bullets: " + String(bullets)),
		pos(width(), 0),
		anchor("topright"),
		color(0, 0, 0),
		fixed(),
	])
	// add score counter
	const scoreText = add([
		text(String(score)),
		pos(width() / 2, 0),
		anchor("top"),
		fixed(),
		color(0, 0, 0)
	])
	add([
		text("Score"),
		pos(width() / 2, 30),
		anchor("top"),
		fixed(),
		color(0, 0, 0),
	])
	// instructions
	addinstruct()
	
	// add player
	const player = add([
		sprite("player"),
		pos(width() / 2, height() - 75),
		scale(0.45),
		area(),
		"player",
	])

	// movement for player
	onKeyDown("left", () => {
		player.move(-PLAYERSPEED, 0)
	})
	onKeyDown("right", () => {
		player.move(PLAYERSPEED, 0)
	})

	// box to sense if enemy is offscreen
	const enemyBox = add([
		rect(width(), 1),
		pos(0, height() + 48),
		anchor("topleft"),
		area(),
		fixed(),
		"offscreenbox",
	])
	
	// spawn enemies
	function spawnenemies() {
		const enemy = add([
			sprite("ghosty"),
			pos(rand(0, width()), 20),
			scale(0.75),
			area(),
			move(DOWN , ENEMYSPEED),
			"enemy",
		])

		// check if enemy collides with player
		enemy.onCollide("player", () => {
			destroy(player)
			destroyAll("enemy")
			destroyAll("bullet")
			destroyAll("cloud")
			addKaboom(player.pos)
			go("losereg", score)
		})

		// check if enemy is offscreen by hitting the offscreen box
		enemy.onCollide("offscreenbox", () => {
			destroy(player)
			destroyAll("enemy")
			destroyAll("bullet")
			destroyAll("cloud")
			addKaboom(player.pos)
			go("losereg", score)
		})
		// wait a random amount to spawn next ghost
		wait(rand(0.5, 1.5), () => {
			spawnenemies()
		})
	}

	// start spawning enemies
	spawnenemies()

	// shoot bullets
	onMousePress(() => {
		// check if player has bullets
		if (bullets > 0) {
			// play shooting sound effect
			play("shoot")
			// add the bullet
			 const bullet = add([
				 sprite("bullet"),
				 pos(player.pos),
				 scale(0.25),
				 area(),
				 move(mousePos().angle(player.pos), BULLETSPEED),
				 rotate(mousePos().angle(player.pos) + 90),
				 offscreen( {destroy: true} ),
				 "bullet",
			 ])
			// subtract bullet from inventory
			 bullets -= 1
			// update bullet counter
			 numberbull.text = "Bullets: " + String(bullets)
			// check if bullet collides with enemy
			 bullet.onCollide("enemy", (enemy) => {
				 play("hit")
				 destroy(enemy)
				 destroy(bullet)
				 addKaboom(bullet.pos)
				 shake(20)
				 // increase score
				 score += 1
				 // update score text
				 scoreText.text = String(score)
				 // increase bullet count
					bullets += 2
				 // update bullet counter
					numberbull.text = "Bullets: " + String(bullets)
			 })}
		// play an error when player has no bullets
		if (bullets <= 0) {
			play("error")
		}
	})
	
	// add background
	setBackground(127, 200, 255)
	// spawn clouds
	function addcloud() {
		add([
			sprite("cloud"),
			scale(rand(0.25, 1.25)),
			pos(0, rand(0, height() - 130)),
			move(RIGHT, CLOUDSPEED),
			offscreen( {destroy: true} ),
			"clouds",
		])
		// wait a random amount to spawn next cloud
		wait(rand(0.5, 1), () => {
			addcloud()
		})
	}

	// start spawning clouds
	addcloud()
})











// insane mode
scene("insane", () => {
	// define simple variables
	let score = 0
	let bullets = 10

	// add bullet counter
	const numberbull = add([
		text("Bullets: " + String(bullets)),
		pos(width(), 0),
		anchor("topright"),
		color(0, 0, 0),
		fixed(),
	])
	// add score counter
	const scoreText = add([
		text(String(score)),
		pos(width() / 2, 0),
		anchor("top"),
		fixed(),
		color(0, 0, 0)
	])
	add([
		text("Score"),
		pos(width() / 2, 30),
		anchor("top"),
		fixed(),
		color(0, 0, 0),
	])
	// run function
	addinstruct()

	// add player
	const player = add([
		sprite("player"),
		pos(width() / 2, height() - 75),
		scale(0.45),
		area(),
		"player",
	])

	// movement for player
	onKeyDown("left", () => {
		player.move(-PLAYERSPEED, 0)
	})
	onKeyDown("right", () => {
		player.move(PLAYERSPEED, 0)
	})

	// box to sense if enemy is offscreen
	const enemyBox = add([
		rect(width(), 1),
		pos(0, height() + 48),
		anchor("topleft"),
		area(),
		fixed(),
		"offscreenbox",
	])

	// spawn enemies
	function spawnenemies() {
		const enemy = add([
			sprite("ghosty"),
			pos(rand(0, width()), 20),
			scale(0.75),
			area(),
			move(DOWN , ENEMYSPEED),
			"enemy",
		])

		// check if enemy collides with player
		enemy.onCollide("player", () => {
			destroy(player)
			destroyAll("enemy")
			destroyAll("bullet")
			destroyAll("cloud")
			addKaboom(player.pos)
			go("losein", score)
		})

		// check if enemy is offscreen by hitting the offscreen box
		enemy.onCollide("offscreenbox", () => {
			destroy(player)
			destroyAll("enemy")
			destroyAll("bullet")
			destroyAll("cloud")
			addKaboom(player.pos)
			go("losein", score)
		})
		// wait a random amount to spawn next ghost
		wait(rand(0.25, 0.5), () => {
			spawnenemies()
		})
	}

	// start spawning enemies
	spawnenemies()

	// shoot bullets
	onMousePress(() => {
		// check if player has bullets
		if (bullets > 0) {
			// play shooting sound effect
			play("shoot")
			// add the bullet
			 const bullet = add([
				 sprite("bullet"),
				 pos(player.pos),
				 scale(0.25),
				 area(),
				 move(mousePos().angle(player.pos), BULLETSPEED),
				 rotate(mousePos().angle(player.pos) + 90),
				 offscreen( {destroy: true} ),
				 "bullet",
			 ])
			// subtract bullet from inventory
			 bullets -= 1
			// update bullet counter
			 numberbull.text = "Bullets: " + String(bullets)
			// check if bullet collides with enemy
			 bullet.onCollide("enemy", (enemy) => {
				 play("hit")
				 destroy(enemy)
				 destroy(bullet)
				 addKaboom(bullet.pos)
				 shake(20)
				 // increase score
				 score += 1
				 // update score text
				 scoreText.text = String(score)
				 // increase bullet count
					bullets += 1
				 // update bullet counter
					numberbull.text = "Bullets: " + String(bullets)
			 })}
		// play an error when player has no bullets
		if (bullets < 1) {
			play("error")
		}
	})

	// add background
	setBackground(127, 200, 255)
	// spawn clouds
	function addcloud() {
		add([
			sprite("cloud"),
			scale(rand(0.25, 1.25)),
			pos(0, rand(0, height() - 130)),
			move(RIGHT, CLOUDSPEED),
			offscreen( {destroy: true} ),
			"clouds",
		])
		// wait a random amount to spawn next cloud
		wait(rand(0.5, 1), () => {
			addcloud()
		})
	}

	// start spawning clouds
	addcloud()
})











// end game screen for regular
scene("losereg", (score) => {
	// when player scores a new highscore
	if(score > highreg) {
		// add the text
		add([
			text("New High Score!\n" + "    Score: " + score, {
						size: 48,
					}),
			pos(center()),
			anchor("center"),
			color(0, 0, 0),
		])
		// update highscore
		highreg = score
		// instructions to play again or go back
		add([
			text("Press space to play again.", {
						size: 24,
					}),
			pos(center().add(0, 100)),
			anchor("center"),
			color(0, 0, 0),
		])
		add([
			text("Press h to go to the home screen", {
						size: 24,
					}),
			pos(center().add(0, 200)),
			anchor("center"),
			color(0, 0, 0),
		])
		// check on what key is pressed
		onKeyPress("space", () => {
			go("regular")
		})
		onKeyPress( "h", () => {
			go("title")
		})
		onMousePress( () => {
			go("regular")
		})
	}
	// when score is less than highscore
	if(score < highreg) {
		// add text
		add([
			text("Score: " + score, {
						size: 48,
					}),
			pos(center()),
			anchor("center"),
			color(0, 0, 0)
		])
		// add their highscore
		add([
			text("Highscore: " + highreg, {
						size: 48,
					}),
			pos(center().add(0, -100)),
			color(0, 0, 0),
			anchor( "center" ),
		])
		// instructions to play again or go back
		add([
			text("Press space to play again.", {
						size: 24,
					}),
			pos(center().add(0, 100)),
			anchor("center"),
			color(0, 0, 0)
		])
		add([
			text("Press h to go to the home screen.", {
						size: 24,
					}),
			pos(center().add(0, 200)),
			anchor("center"),
			color(0, 0, 0),
		])
		
		// check for key press
		onKeyPress( "space", () => {
			go("regular")
		})
		onKeyPress("h", () => {
			go("title")
		})
		onMousePress( () => {
			go("regular")
		})
	}
})











// end game screen for insane mode
scene("losein", (score) => {
	// when player scores a new highscore
	if(score > highin) {
		// add the text
		add([
			text("New High Score!\n" + "    Score: " + score, {
						size: 48,
					}),
			pos(center()),
			anchor("center"),
			color(0, 0, 0),
		])
		// update highscore
		highin = score
		// instructions to play again or go back
		add([
			text("Press space to play again.", {
						size: 24,
					}),
			pos(center().add(0, 100)),
			anchor("center"),
			color(0, 0, 0),
		])
		add([
			text("Press h to go to the home screen", {
						size: 24,
					}),
			pos(center().add(0, 200)),
			anchor("center"),
			color(0, 0, 0),
		])
		// check on what key is pressed
		onKeyPress("space", () => {
			go("insane")
		})
		onKeyPress( "h", () => {
			go("title")
		})
		onMousePress( () => {
			go("insane")
		})
	}
	// when score is less than highscore
	if(score < highin) {
		// add text
		add([
			text("Score: " + score, {
						size: 48,
					}),
			pos(center()),
			anchor("center"),
			color(0, 0, 0)
		])
		// add their highscore
		add([
			text("Highscore: " + highin, {
						size: 48,
					}),
			pos(center().add(0, -100)),
			color(0, 0, 0),
			anchor( "center" ),
		])
		// instructions to play again or go back
		add([
			text("Press space to play again.", {
						size: 24,
					}),
			pos(center().add(0, 100)),
			anchor("center"),
			color(0, 0, 0)
		])
		add([
			text("Press h to go to the home screen.", {
						size: 24,
					}),
			pos(center().add(0, 200)),
			anchor("center"),
			color(0, 0, 0),
		])

		// check for key press
		onKeyPress( "space", () => {
			go("insane")
		})
		onKeyPress("h", () => {
			go("title")
		})
		onMousePress( () => {
			go("insane")
		})
	}
})

// start game screen
scene("title", () => {
	// decorations
	add([
		sprite("player"),
		scale(0.40),
		pos(10, 10),
		anchor("top"),
		rotate(-45),
	])
	add([
		sprite("ghosty"),
		pos(width() - 10, 10),
		anchor("top"),
		rotate(45),
	])
	// title
	add([
		text("Blobby Shooter", {
			size: 64,
		}),
		pos(center()),
		anchor("center"),
		color(0,0,0),
	])
	// instructions to start
	add([
		text("Click r to start regular mode", {
					size: 48,
				}),
		pos(center().add(0, 100)),
		anchor("center"),
		color(0, 0, 0),
	])
	add([
		text("Click i to start insane mode", {
					size: 48,
				}),
		pos(center().add(0, 200)),
		anchor("center"),
		color(0, 0, 0),
	])
	
	// show highscore at the bottom
	add([
		text("Highscore for regular: " + highreg, {
			size: 24,
		}),
		pos(width() / 2, 0),
		anchor("top"),
		color(0, 0, 0),
		])
	add([
		text("Highscore for insane: " + highin, {
			size: 24,
		}),
		pos(width() / 2, 30),
		anchor("top"),
		color(0, 0, 0),
		])
	// when a key is pressed, start game
	onKeyPress("r", () => {
		go("regular")
	})
	onKeyPress("i", () => {
		go("insane")
	})
	
	// set the background color
	setBackground(127, 200, 255)
})

// show the title screen
go("title")

